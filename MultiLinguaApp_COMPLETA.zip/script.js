
const donationText = {
  it: `Questa app è stata creata con il cuore per aiutare chiunque voglia imparare una nuova lingua in modo gratuito, semplice e divertente. 
Se ti è stata utile e desideri supportare il progetto, sappi che ogni contributo andrà a sostenere un sogno personale: il mio matrimonio. 
Ogni piccola donazione sarà un gesto che contribuirà a rendere speciale un giorno importante della mia vita. 
Dedicato al matrimonio di Simone e Olga - 02/08/2025`,
  en: `This app was created with love to help anyone learn a new language for free, easily and with fun.
If it has been useful to you and you want to support the project, know that every contribution will support a personal dream: my wedding.
Every small donation will help make a special day even more beautiful.
Dedicated to the wedding of Simone and Olga - 08/02/2025`,
  fr: `Cette application a été créée avec le cœur pour aider chacun à apprendre une langue gratuitement, simplement et de manière ludique.
Si elle vous a été utile, sachez que chaque contribution soutiendra un rêve personnel : mon mariage.
Chaque petit don rendra ce jour spécial encore plus inoubliable.
Dédié au mariage de Simone et Olga - 02/08/2025`
};

const lang = navigator.language.slice(0, 2) || "it";
document.getElementById("donation-text").textContent = donationText[lang] || donationText["it"];

document.getElementById("paypal-button-home").onclick = () => {
  window.open("https://www.paypal.com/paypalme/simoneandreacapo", "_blank");
};
